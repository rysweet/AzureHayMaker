def hello() -> str:
    return "Hello from azure-haymaker!"


# Trigger dev deployment
